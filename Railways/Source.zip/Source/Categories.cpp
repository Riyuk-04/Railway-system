//ISHAN GOEL -> 19CS30052

#include "BookingCategory.h"
#include "Categories.h"

General::General(){}

General::~General(){}

Priority::Priority(){}

Priority::~Priority(){}

Tatkal::Tatkal(){}

Tatkal::~Tatkal(){}

PremiumTatkal::PremiumTatkal(){}

PremiumTatkal::~PremiumTatkal(){}

Concessional::Concessional(){}

Concessional::~Concessional(){}

SeniorCitizen::SeniorCitizen(){}

SeniorCitizen::~SeniorCitizen(){}

Divyaang::Divyaang(){}

Divyaang::~Divyaang(){}

Blind::Blind(){}

Blind::~Blind(){}

OH::OH(){}

OH::~OH(){}

TB::TB(){}

TB::~TB(){}

Cancer::Cancer(){}

Cancer::~Cancer(){}
