//ISHAN GOEL -> 19CS30052

#include "BookingCategory.h"

BookingCategory::BookingCategory() {}

BookingCategory::~BookingCategory() {}

