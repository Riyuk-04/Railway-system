ISHAN GOEL --> 19CS30052

Application_TestSuite1.cpp:
	It contains appliocation testing for test suite 1

Application_TestSuite2.cpp:
	It contains appliocation testing for test suite 2

UnitTest.cpp:
	It contains code for Unit Testing of each class

G++ Compiler Version Used:
	g++ (Ubuntu 7.5.0-3ubuntu1~18.04) 7.5.0

Commands to run:
=> For "test suite 1" application testing:
	$ g++ Application_TestSuite1.cpp Booking.cpp Station.cpp BookingCategory.cpp Categories.cpp BookingClasses.cpp Passenger.cpp Date.cpp Railways.cpp

	$ ./a.out

=> For "test suite 1" application testing:
	$ g++ Application_TestSuite2.cpp Booking.cpp Station.cpp BookingCategory.cpp Categories.cpp BookingClasses.cpp Passenger.cpp Date.cpp Railways.cpp
	
	$ ./a.out

=> For Unit Testing:
	$ g++ UnitTest.cpp Booking.cpp Station.cpp BookingCategory.cpp Categories.cpp BookingClasses.cpp Passenger.cpp Date.cpp Railways.cpp
	
	$ ./a.out
	
